﻿// See https://aka.ms/new-console-template for more information
////Console.WriteLine("Hello, World!");
////Console.WriteLine("Hello, Ajith!");
/// <summary>
/// 
using System.Data;
using System.Data.SqlClient;
using System.Reflection.PortableExecutable;
/// </summary>
class Program 
{ 

    static void Main()
    {
        Console.WriteLine("welcome Ajith");

        //var connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=dotnet;Integrated Security=True";
        var connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=practice;Integrated Security=True";
        //var sql = "select id,name from City";
        var sql = "select eid,vegname,cost from vendors";
        //SqlDataReader reader;

        //DataTable table = new DataTable();

        using (SqlConnection conn = new SqlConnection(connection) )
        {
            conn.Open();

            Console.WriteLine("fetching data using datareader - method1");

            using (SqlCommand command = new SqlCommand(sql, conn))
            {
                //reader = command.ExecuteReader();
                //table.Load(reader);
                //reader.Close();
                //conn.Close();

                using(SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //Console.WriteLine("{0}-{1}",reader.GetInt32(0),reader.GetString(1));
                        Console.WriteLine("{0}-{1}-{2}" ,reader.GetInt32(0),reader.GetString(1),reader.GetInt32(2));
                    }
                
                }

            }

            conn.Close();


            
        }

        Console.WriteLine("fetching data using dataadapter and datatable");
        using (SqlConnection conn = new SqlConnection(connection))
        {
            conn.Open();
           


            using(SqlDataAdapter adapter = new SqlDataAdapter(sql,conn))
            {
                DataTable dt = new DataTable();

                adapter.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    Console.WriteLine("{0}-{1}-{2}", row["eid"], row["vegname"], row["cost"]);
                }
            }

            conn.Close();
        }

        Console.WriteLine("fetching data using dataadapter and dataset");
        using (SqlConnection conn = new SqlConnection(connection))
        {
            conn.Open();

            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                DataSet ds = new DataSet();

                adapter.Fill(ds);

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Console.WriteLine("{0}-{1}-{2}", row["eid"], row["vegname"], row["cost"]);

                }


            }

        }
    }
}
    
