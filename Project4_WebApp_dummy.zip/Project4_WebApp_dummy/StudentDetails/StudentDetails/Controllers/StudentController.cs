﻿using Microsoft.AspNetCore.Mvc;
using StudentDetails.model;

namespace StudentDetails.Controllers
{
    public class StudentController : Controller
    {

        StudentDataAccessLayer studentDataAccessLayer = new StudentDataAccessLayer();

        public IActionResult Index()
        {

            List<Student> students = new List<Student>();

            students = studentDataAccessLayer.GetAllStudents().ToList();
            return View(students);
        }

        [HttpGet("/Create")]
        public IActionResult Create() 
        {
            return View();
        }
    }
}
