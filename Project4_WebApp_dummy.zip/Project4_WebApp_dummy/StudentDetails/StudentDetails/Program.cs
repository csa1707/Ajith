var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddControllersWithViews();

//builder.Services.AddMvc(option => option.EnableEndpointRouting = false);

var app = builder.Build();

//app.UseMvc();


//app.UseMvc(routes =>
//{
//    //routes.MapRoute(
//    //   name: "create",
//    //   template: "{controller=Student}/{action=Create}/{id?}");

//    routes.MapRoute(
//        name: "default",
//        template: "{controller=Student}/{action=Index}/{id?}");

    
//});

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();

app.UseRouting();

//app.UseEndpoints(endpoints =>
//{
//    endpoints.MapRazorPages();
//    endpoints.MapControllerRoute(
//        name: "Create", pattern: "{controller=Student}/{action=Create}");
//});



app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Student}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "create",
    pattern: "{controller=Student}/{action=Create}/{id?}");

app.MapRazorPages();

app.Run();
