﻿using System.Data.SqlClient;

namespace StudentDetails.model
{
    public class StudentDataAccessLayer
    {

        string connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=webapps;Integrated Security=True";

        public IEnumerable<Student> GetAllStudents()
        {
            List<Student> studentslist = new List<Student>() ;

            var getstudentspname = "spGetAllStudent";

            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(getstudentspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = getstudentspname;

                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Student stud    = new Student();
                        stud.Name = reader["Name"].ToString();
                        stud.Department = reader["Department"].ToString();
                        stud.City = reader["City"].ToString();

                        stud.Gender = reader["Gender"].ToString();

                        studentslist.Add(stud);

                    }

                    conn.Close();
                }
            }

            return studentslist;
        }

        // to add new student

        public void AddStudent(Student stud)
        {
            var addstudenspname = "spAddstudent";
            using (SqlConnection conn = new SqlConnection(connection))
            {

                using (SqlCommand cmd = new SqlCommand(addstudenspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = addstudenspname;

                    conn.Open();

                    cmd.Parameters.Add("@Name",System.Data.SqlDbType.VarChar , 10).Value = stud.Name;
                    cmd.Parameters.Add("@City", System.Data.SqlDbType.VarChar, 10).Value = stud.City;
                    cmd.Parameters.Add("@Department", System.Data.SqlDbType.VarChar, 10).Value = stud.Department;
                    cmd.Parameters.Add("@Gender", System.Data.SqlDbType.VarChar, 10).Value = stud.Gender;

                    cmd.ExecuteNonQuery();

                    conn.Close();

                }

            }

        }
        //to update specific student
        public void UpdateStudent(Student stud)
        {
            var updatestudenspname = "spUpdateStudent";
            using (SqlConnection conn = new SqlConnection(connection))
            {

                using (SqlCommand cmd = new SqlCommand(updatestudenspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = updatestudenspname;

                    conn.Open();

                    cmd.Parameters.Add("@Name", System.Data.SqlDbType.VarChar, 10).Value = stud.Name;
                    cmd.Parameters.Add("@City", System.Data.SqlDbType.VarChar, 10).Value = stud.City;
                    cmd.Parameters.Add("@Department", System.Data.SqlDbType.VarChar, 10).Value = stud.Department;
                    cmd.Parameters.Add("@Gender", System.Data.SqlDbType.VarChar, 10).Value = stud.Gender;
                    cmd.Parameters.Add("@StudId", System.Data.SqlDbType.VarChar, 10).Value = stud.StudId;

                    cmd.ExecuteNonQuery();

                    conn.Close();

                }

            }

        }

        //to delete specific student
        public void DeleteStudent(int id)
        {
            var deletestudenspname = "spDeleteStudent";
            using (SqlConnection conn = new SqlConnection(connection))
            {

                using (SqlCommand cmd = new SqlCommand(deletestudenspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = deletestudenspname;

                    conn.Open();
                    
                    cmd.Parameters.Add("@StudId", System.Data.SqlDbType.VarChar, 10).Value = id;

                    cmd.ExecuteNonQuery();

                    conn.Close();

                }

            }

        }

        //to get specific student details

        public Student GetStudentData(int id)
        {

            Student student = new Student();

            var query = "select StudId,name,city,department,gender from tblStudent where StudId=" + id;

            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {

                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        student.StudId =Convert.ToInt32(reader["StudId"]);
                        student.Name = reader["Name"].ToString();
                        student.Department = reader["Department"].ToString();
                        student.City = reader["City"].ToString();
                        student.Gender = reader["Gender"].ToString();

                    }

                    conn.Close();

                }

            }

            return student;

        }



    }
}
