﻿namespace StudentDetails.model
{
    public class Vegetable
    {
    }
}
