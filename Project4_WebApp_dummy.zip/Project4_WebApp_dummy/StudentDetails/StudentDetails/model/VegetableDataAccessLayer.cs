﻿namespace StudentDetails.model
{
    public class VegetableDataAccessLayer
    {
    }
}
