﻿using Microsoft.AspNetCore.Mvc;
using CarDetails.Models;
using System.Collections.Generic;
using System.Linq;
using StudentDetails.Models;
using VegetableDetails.Models;
using System;

namespace StduentDetails.Controllers
{
    public class CarController : Controller
    {
        CarDataAccessLayer CarDataAccessLayer = new CarDataAccessLayer();
        public IActionResult Index()
        {
            List<Car> cars = new List<Car>();

            cars = CarDataAccessLayer.spgetallcar().OrderByDescending(x => x.id).ToList();

            return View(cars);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Create([Bind] Car car)
        {
            if (ModelState.IsValid)
            {
                CarDataAccessLayer.Addcar(car);

                return RedirectToAction("Index");

            }

            return View(car);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Car car = CarDataAccessLayer.GetCar(id);

            return View(car);
        }
        [HttpPost]
        public IActionResult Edit([Bind] Car car)
        {
            if (ModelState.IsValid)
            {
                CarDataAccessLayer.Updatecar(car);

                return RedirectToAction("Index");

            }
            return View(car);
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            Car car = CarDataAccessLayer.GetCar(id);

            return View(car);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Car car = CarDataAccessLayer.GetCar(id);

            return View(car);
        }
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirnm(int id)
        {
            CarDataAccessLayer.Deletecar(id);

            return RedirectToAction("Index");
        }
        //[HttpPost]
        //public JsonResult GetAjaxMethod(string id)
        //{
        //    Student stud = CarDataAccessLayer.Updatecar(Convert.ToInt32(id));


        //    return Json(stud);
        //}
    }
}
