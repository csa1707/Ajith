﻿using Microsoft.AspNetCore.Mvc;
using StudentDetails.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StduentDetails.Controllers
{
    public class StudentController : Controller
    {

        StudentDataAccessLayer studentDataAccessLayer = new StudentDataAccessLayer();


        public IActionResult Index()
        {
            List<Student> students = new List<Student>();

            students = studentDataAccessLayer.GetAllStudents().ToList();

            ViewBag.College = "K.Ramakrishnan college of Eng";

            ViewData["College"] = "K.Ramakrishnan college of Eng";

            TempData["College1"] = "K.Ramakrishnan college of Eng1";

            return View(students);
        }

        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Create([Bind]Student student)
        {

           

            if (ModelState.IsValid)
            {
                studentDataAccessLayer.AddStudent(student);

                return RedirectToAction("Index");
            }


            return View(student);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Student stud = studentDataAccessLayer.GetStudentData(id);

            return View(stud);
        }

        [HttpPost]
        public IActionResult Edit([Bind] Student student)
        {
            if (ModelState.IsValid)
            {
                studentDataAccessLayer.UpdateStudent(student);

                return RedirectToAction("Index");

            }

            return View(student);
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            Student stud = studentDataAccessLayer.GetStudentData(id);

            return View(stud);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Student stud = studentDataAccessLayer.GetStudentData(id);

            return View(stud);


        }

        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirnm(int id)
        {
            studentDataAccessLayer.DeleteStudent(id);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public JsonResult GetAjaxMethod(string studentid)
        {
            //Student stud = new Student();

            //stud.Name = "Ravikumar";
            //stud.Department = "ECE";
            //stud.City = "Mumbai";
            //stud.Gender = "Male";

            Student stud = studentDataAccessLayer.GetStudentData(Convert.ToInt32(studentid));


            return Json(stud);
        }


    }
}
