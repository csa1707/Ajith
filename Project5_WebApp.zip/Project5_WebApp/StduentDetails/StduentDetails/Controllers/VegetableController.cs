﻿using Microsoft.AspNetCore.Mvc;
using VegetableDetails.Models;
using System.Collections.Generic;
using System.Linq;
using StudentDetails.Models;

namespace StduentDetails.Controllers
{
    public class VegetableController : Controller
    {
        VegetableDataAccessLayer vegetableDataAccessLayer = new VegetableDataAccessLayer();

        public IActionResult Index()
        {
            List<Vegetable> vegetables = new List<Vegetable>();

            vegetables = vegetableDataAccessLayer.spgetallveg().OrderByDescending(x=>x.eid).ToList();

            return View(vegetables);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Create([Bind] Vegetable vegetable)
        {
            if (ModelState.IsValid)
            {
                vegetableDataAccessLayer.Addvegetable(vegetable);

                return RedirectToAction("Index");

            }

            return View(vegetable);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Vegetable veg = vegetableDataAccessLayer.GetVegetable(id);

            return View(veg);
        }
        [HttpPost]
        public IActionResult Edit([Bind] Vegetable vegetable)
        {
            if (ModelState.IsValid)
            {
                vegetableDataAccessLayer.Updatevegetable(vegetable);

                return RedirectToAction("Index");

            }
            return View(vegetable);
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            Vegetable veg = vegetableDataAccessLayer.GetVegetable(id);

            return View(veg);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Vegetable veg = vegetableDataAccessLayer.GetVegetable(id);

            return View(veg);
        }
        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirnm(int id)
        {
            vegetableDataAccessLayer.Deletevegetable(id);

            return RedirectToAction("Index");
        }
    }
}
