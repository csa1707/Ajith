﻿using System.ComponentModel.DataAnnotations;

namespace CarDetails.Models
{
    public class Car
    {
        public int id { get; set; }

        [Required]
        public string carname { get; set; }

        [Required]
        public int cost { get; set; }
    }
}
