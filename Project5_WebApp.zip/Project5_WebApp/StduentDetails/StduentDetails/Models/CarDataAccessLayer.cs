﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;


namespace CarDetails.Models
{
    public class CarDataAccessLayer
    {
        string connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=practice;Integrated Security=True";
        public IEnumerable<Car> spgetallcar()
        {
            List<Car> Carslist = new List<Car>();
            var getcarspname = "spgetallcar";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(getcarspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = getcarspname;

                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Car cars = new Car();

                        cars.id = Convert.ToInt32(reader["id"]);
                        cars.carname = reader["carname"].ToString();
                        cars.cost = Convert.ToInt32(reader["cost"]);

                        Carslist.Add(cars);

                    }
                    conn.Close();
                }
            }
            return Carslist;
        }
        public void Addcar(Car car)
        {
            var addcarspname = "insertcar";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(addcarspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = addcarspname;

                    conn.Open();

                    //cmd.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = car.id;
                    cmd.Parameters.Add("@carname", System.Data.SqlDbType.VarChar, 20).Value = car.carname;
                    cmd.Parameters.Add("@cost", System.Data.SqlDbType.Int).Value = car.cost;

                    cmd.ExecuteNonQuery();

                    conn.Close();

                }
            }
        }
        public void Updatecar(Car car)
        {
            var updatecarspname = "spupdatecar";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(updatecarspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = updatecarspname;

                    conn.Open();

                    cmd.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = car.id;
                    cmd.Parameters.Add("@carname", System.Data.SqlDbType.VarChar, 20).Value = car.carname;
                    cmd.Parameters.Add("@cost", System.Data.SqlDbType.Int).Value = car.cost;

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
        }
        public void Deletecar(int id)
        {
            var deletecarspname = "deletecar";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(deletecarspname, conn))
                {
                    cmd.CommandText = deletecarspname;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    conn.Open();

                    cmd.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = id;

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
        }
        public Car GetCar(int id)
        {
            Car cars = new Car();

            var query = "select id,carname,cost from cars where id=" + id;

            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cars.id = reader.GetInt32(0);
                        cars.carname = reader.GetString(1);
                        cars.cost = reader.GetInt32(2);
                    }
                    conn.Close();
                }
            }
            return cars;
        }
    }
}
