﻿using System.ComponentModel.DataAnnotations;

namespace VegetableDetails.Models
{
    public class Vegetable
    {
        public int eid { get; set; }

        [Required]
        public string vegname { get; set; }

        [Required]
        public int cost { get; set; }
       
    }
}
