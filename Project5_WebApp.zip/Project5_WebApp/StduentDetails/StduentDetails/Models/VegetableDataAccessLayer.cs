﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace VegetableDetails.Models
{
    public class VegetableDataAccessLayer
    {
        string connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=practice;Integrated Security=True";

        public IEnumerable<Vegetable> spgetallveg()
        {
            List<Vegetable> Vegetablelist = new List<Vegetable>();
            var getvegspname = "spgetallveg";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(getvegspname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = getvegspname;

                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();    

                    while (reader.Read())
                    {
                        Vegetable Veg = new Vegetable();

                        Veg.eid = Convert.ToInt32(reader["eid"]);
                        Veg.vegname = reader["vegname"].ToString();
                        Veg.cost = Convert.ToInt32(reader["cost"]);

                        Vegetablelist.Add(Veg);

                    }
                    conn.Close();   
                }
            }
            return Vegetablelist;
        }

        public void Addvegetable(Vegetable Veg)
        {
            var addvegetablespname = "spaddveg";
            using(SqlConnection conn = new SqlConnection(connection))
            {
                using(SqlCommand cmd = new SqlCommand(addvegetablespname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText=addvegetablespname;

                    conn.Open();    

                    cmd.Parameters.Add("@eid",System.Data.SqlDbType.Int ).Value = Veg.eid;
                    cmd.Parameters.Add("@vegname", System.Data.SqlDbType.VarChar, 20).Value = Veg.vegname;
                    cmd.Parameters.Add("@cost",System.Data.SqlDbType.Int).Value = Veg.cost;

                    cmd.ExecuteNonQuery();

                    conn.Close();
                   
                }
            }
        }
        public void Updatevegetable(Vegetable Veg)
        {
            var updatevegetablespname = "spupdateveg";
                using(SqlConnection conn = new SqlConnection(connection))
            {
                using(SqlCommand cmd =new SqlCommand(updatevegetablespname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = updatevegetablespname;

                    conn.Open();

                    cmd.Parameters.Add("@eid", System.Data.SqlDbType.Int).Value = Veg.eid;
                    cmd.Parameters.Add("@vegname", System.Data.SqlDbType.VarChar, 20).Value = Veg.vegname;
                    cmd.Parameters.Add("@cost", System.Data.SqlDbType.Int).Value = Veg.cost;

                    cmd.ExecuteNonQuery ();

                    conn.Close();
                }
            }
        }
        public void Deletevegetable(int id)
        {
            var deletevegetablespname = "spdeletevegetable";
                using(SqlConnection conn = new SqlConnection(connection))
            {
                using(SqlCommand cmd =new SqlCommand(deletevegetablespname, conn))
                {
                    cmd.CommandText= deletevegetablespname;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                           
                    conn.Open ();   

                    cmd.Parameters.Add("@eid",System.Data.SqlDbType.Int).Value = id;

                    cmd.ExecuteNonQuery();

                    conn.Close ();
                }
            }
        }
        public Vegetable GetVegetable(int id)
        {
            Vegetable vegetable = new Vegetable();

            var query = "select eid,vegname,cost from vendors where eid=" + id;

            using(SqlConnection conn = new SqlConnection(connection))
            {
                using(SqlCommand cmd = new SqlCommand(query, conn))
                {
                    //cmd.CommandText= query;
                    //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    conn.Open ();
                    SqlDataReader reader = cmd.ExecuteReader(); 
                    while (reader.Read())
                    {
                        vegetable.eid= reader.GetInt32(0);
                        vegetable.vegname= reader.GetString(1);
                        vegetable.cost= reader.GetInt32(2);
                    }
                    conn.Close ();
                }
            }
            return vegetable;
        }
    }
}
