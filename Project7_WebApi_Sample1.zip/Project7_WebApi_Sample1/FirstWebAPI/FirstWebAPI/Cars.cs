﻿namespace FirstWebAPI
{
    public class Cars
    {
        public int id { get; set; }

        public string carname {  get; set; }
    }
}
