﻿namespace FirstWebAPI
{
    public class Vegetable
    {
        public int eid { get; set; }

        public string vegname { get; set; }

        public int cost { get; set; }
    }
}
