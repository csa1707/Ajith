﻿using System.Data.SqlClient;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace SecondAPI.Controllers
public class notes1
{
	{
		 public int id { get; set; }

		 public string description { get; set; }
	}
}
