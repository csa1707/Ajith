﻿using System.Data.SqlClient;

class Program
{

    static void Main()
    {

        
        {



            Console.WriteLine("hello ajith , welcome to stored procedure program");

            var connection = "Data Source= DESKTOP-IURUBDV\\SQLEXPRESS; Initial Catalog=practice;Integrated Security=True";

            var spname = "getemploydetails";

            Console.WriteLine("execution of create sp");

            using (SqlConnection conn = new SqlConnection(connection))
            {

                conn.Open();

                using (SqlCommand cmd = new SqlCommand(spname, conn))
                {

                    cmd.CommandText = spname;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                            Console.WriteLine("{0}-{1}-{2}-{3} ", reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3));
                        }

                    }


                }

                conn.Close();
            }

            //Console.WriteLine("execution of insert sp");
            //var insertsp = "insertemploydetails";
            //using (SqlConnection conn = new SqlConnection(connection))
            //{
            //    conn.Open();

            //    using (SqlCommand cmd = new SqlCommand(insertsp, conn))
            //    {

            //        cmd.CommandText = insertsp;
            //        cmd.CommandType = System.Data.CommandType.StoredProcedure;


            //        cmd.Parameters.Add("@studentID", System.Data.SqlDbType.Int).Value = 17;
            //        cmd.Parameters.Add("@name", System.Data.SqlDbType.VarChar, 10).Value = "raj";
            //        cmd.Parameters.Add("@gender", System.Data.SqlDbType.VarChar).Value = "male";
            //        cmd.Parameters.Add("@depid", System.Data.SqlDbType.Int).Value = 12;

            //        cmd.ExecuteNonQuery();
            //    }
            //    conn.Close();
            //    Console.WriteLine("Data Inserted sucessfully");
            //}
            //Console.WriteLine("Hi ajith, Delete data from sp");
            //    var deletesp = "deletespdata";
            //    using(SqlConnection conn = new SqlConnection(connection))
            //{ 
            //    conn.Open();
            //    using(SqlCommand cmd = new SqlCommand(deletesp, conn))
            //    { 
            //        cmd.CommandText = deletesp;
            //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //        cmd.Parameters.Add("@studentID", System.Data.SqlDbType.Int).Value = 18;

            //        cmd.ExecuteNonQuery();
            //    }
            //    conn.Close();
            //    Console.WriteLine("data deleted sucessfully");
            //}
                Console.WriteLine("update data in stored procedure");
            var updatesp = "updatespdata";
            using(SqlConnection conn = new SqlConnection(connection)) 
            { 
                conn.Open();
                using(SqlCommand cmd = new SqlCommand(updatesp, conn))
                { 
                    cmd.CommandText = updatesp;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.Add("@depid", System.Data.SqlDbType.Int).Value = 12;
                    cmd.Parameters.Add("@studentID", System.Data.SqlDbType.Int).Value = 12;

                    var count = cmd.ExecuteNonQuery();
                }
                conn.Close();
                Console.WriteLine("updated data sucessfully")
            }
        }
    }

}