--create database dec13

--use dec13


--create table [order]

create table orders(
Id int  null,
orderid varchar(10) not null
)

--delete from orders    --- it delete only data or records but not table schema

--drop table orders

--insert into orders(Id,orderid) values(2,'bcp')

--select * from orders

create table orders1(
Id int not null,
orderid varchar(10) not null,
PRIMARY KEY (Id)
)

insert into orders1(Id,orderid) values(null,'rcp')

select * from orders1