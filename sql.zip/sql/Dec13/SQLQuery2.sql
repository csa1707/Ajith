create table orders2(
Id int identity(1,2) primary key,
orderid varchar(10) not null
)

--drop table orders2

--insert into orders2(orderid) values('ajith')

--insert into orders2(orderid) values('arun')

alter table orders2
add cost int null

--alter table orders2
--RENAME column "cost" to "price"

EXEC sp_RENAME 'orders2.cost', 'price', 'COLUMN'

select * from orders2

delete from orders2 where id=3

delete  from orders2

--truncate table orders2