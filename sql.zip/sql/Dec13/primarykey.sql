create database practice
use practice

create table employee(
eid int not null,
ename varchar(100),
eage int not null
)

insert into employee(eid,ename,eage) values(1,'kumar',20)
insert into employee(eid,ename,eage) values(2,'dhoni',23)
insert into employee(eid,ename,eage) values(3,'virat',28)


create table employee1(
ename varchar(100),
personid int not null,
PRIMARY KEY (personid)
)
select * from [dbo].[employee1] where eid = 1


insert into employee1(ename, personid) values('raj',3)


