--use dec13

select * from [dbo].[orders2]

update [dbo].[orders2]
set cost=1000 where id=5
--where id=5

--insert into orders2(orderid,cost) values('ajith',3000)

--select distinct orderid,cost from orders2


select * from [dbo].[orders2] order by id desc

select orderid,cost from [dbo].[orders2]

select * from [dbo].[orders2] where orderid='ajith' and cost=3000

select * from [dbo].[orders2] where orderid='ajith' or cost=3000

select top 2 * from  [dbo].[orders2] order by id desc

select min(cost) from [dbo].[orders2]

select max(cost) from [dbo].[orders2]

select sum(cost) from [dbo].[orders2]

select count(*) from [dbo].[orders2]


create function getmaxordercost()
returns int
as
begin
  return (select max(cost) from [dbo].[orders2] )
end

--select @@VERSION

select  [dbo].getmaxordercost()

create function getorderidbymaxordercost()
returns varchar(20)
as
begin
  return (select orderid from [dbo].[orders2] where cost=2000 )
end


select  [dbo].getorderidbymaxordercost()


create function getorderidbymaxordercost1(@cost int)
returns varchar(20)
as
  return (select orderid from [dbo].[orders2] where cost=@cost )

select  [dbo].getorderidbymaxordercost1(1000)


alter function getallorders(@cost int)
returns table
as
   return (select * from [dbo].[orders2] where cost =@cost)

select * from [dbo].getallorders(3000)



