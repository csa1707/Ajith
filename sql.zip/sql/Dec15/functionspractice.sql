use practice

select sum(cost) from [dbo].[vendors]

select min(cost) from [dbo].[vendors]

select max(cost) from [dbo].[vendors]

select count(*) from [dbo].[vendors]

select avg(cost) from [dbo].[vendors]

select top 1 * from [dbo].[vendors] order by eid

select top 1 * from [dbo].[vendors] order by eid desc

select distinct eid,vegname from [dbo].[vendors]

create function getmaxcost()
returns int
as
begin
  return (select max(cost) from [dbo].[vendors])
end

select [dbo].getmaxcost()

create function geteidcost()
returns varchar(20)
as
begin
  return (select vegname from [dbo].[vendors] where eid = 101)
end

select [dbo].geteidcost()

create function geteidgn(@epid int)
returns table
as
 return (select * from [dbo].[vendors] where eid = @epid)

select * from [dbo].geteidgn(100)

create