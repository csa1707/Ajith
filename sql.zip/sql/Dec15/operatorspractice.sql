select * from [dbo].[vendors] where eid = 101 and cost = 50

select * from [dbo].[vendors] where eid =104 or cost = 77

select * from [dbo].[vendors] where cost IN (77,20)

select * from [dbo].[vendors] where cost between 20 and 70

select * from [dbo].[vendors] where vegname like 'b%'

