--create database dec16

--use dec16

create table person(
Id int not null primary key ,
name varchar(10) not null,
age int not null
)

create table order1(
Id int not null primary key,
ordernumber int not null,
personid int not null,
foreign key (personid) references person(Id)
)

--insert into person(Id,name,age) values(1,'ajith',22)


--insert into person(Id,name,age) values(2,'kumar',23)


--insert into person(Id,name,age) values(5,'ravi',30)



select * from [dbo].[person]

insert into order1(Id,ordernumber,personid) values(5,1343,null)


select * from [dbo].[person]

select * from [dbo].[order1]

--select * from [dbo].[order1] where personid=1

select * from [dbo].[order1] where personid in (select id from [dbo].[person] where name='ajith')

select per.Id,per.name,per.age,ord.ordernumber from [dbo].[person] per
inner join [dbo].[order1] ord on per.Id=ord.personid


select per.Id,per.name,per.age,ord.ordernumber from [dbo].[person] per left join [dbo].[order1] ord on per.Id=ord.personid

select per.Id,per.name,per.age,ord.ordernumber from [dbo].[order1] ord right join [dbo].[person] per on per.Id=ord.personid
