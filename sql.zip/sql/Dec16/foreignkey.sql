USE [practice]

create table vendors(
eid int primary key,
vegname varchar(20),
cost int 
)

insert into vendors(eid,vegname,cost) values(102,'drumstick',77)

create table buyers(
fruitname varchar(20),
personid int,
FOREIGN KEY (personid) references vendors(eid)
)

insert into buyers(fruitname,personid) values('bananna',102)

--insert into buyers(fruitname,personid) values('grapes',105)

select * from buyers where personid in (select eid from [dbo].[vendors] where vegname = 'drumstick')