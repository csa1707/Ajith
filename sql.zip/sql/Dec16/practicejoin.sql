use dec16


create table student(
studentID int not null primary key ,
name varchar(10) not null,
dob date ,
gender varchar(20) not null
)

create table marks(
marksid int not null,
studentID int not null primary key,
subject varchar(20),
marksscored int not null
)

select * from [dbo].[student]

select * from [dbo].[marks]
--update marks
--set studentID=103 where marksid = 1

insert into student(studentID, name, dob, gender) values(100,'Ajay', '05/01/2000', 'male')

insert into student(studentID, name, dob, gender) values(101,'malar', '08/01/2000', 'Female')

insert into student(studentID, name, dob, gender) values(102,'vijay', '10/01/2000', 'male')

insert into student(studentID, name, dob, gender) values(103,'kumar', '12/01/2000', 'male')


insert into marks(marksid, studentID, subject, marksscored) values(5,104,'sanscript',75)

--select * from [dbo].[marks] where studentID=103

--select * from [dbo].[marks] where studentID in (select studentID from [dbo].[student] where name='kumar')

select stu.studentID,stu.name,stu.dob,stu.gender
from [dbo].[student] stu
inner join [dbo].[marks] mar
on stu.studentID=mar.studentID


select stu.studentID,stu.name,stu.dob,stu.gender
from [dbo].[student] stu
left join [dbo].[marks] mar
on stu.studentID=mar.studentID

select stu.studentID,stu.name,stu.dob,stu.gender
from [dbo].[student] stu
right join [dbo].[marks] mar
on stu.studentID=mar.studentID