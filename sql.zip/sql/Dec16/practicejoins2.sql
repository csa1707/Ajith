use practice

create table employ(
studentID int not null primary key  ,
name varchar(10) not null,
gender varchar(20) not null,
depid int not null 
)

create table depart1(
depid int not null primary key,
depname varchar(50) not null
)
insert into employ(studentID, name, gender,depid) values(10,'kumari', 'female',11)
insert into employ(studentID, name, gender,depid) values(11,'kumari', 'female',12)
insert into employ(studentID, name, gender,depid) values(12,'ravi', 'male',11)
insert into employ(studentID, name, gender,depid) values(13,'teja', 'male',13)

insert into employ(studentID, name, gender,depid) values(14,'velu', 'male',14)
insert into employ(studentID, name, gender,depid) values(15,'raja', 'male',13)

select * from [dbo].[employ]
select * from [dbo].[depart1]
sp_help depart1
insert into depart1(depid,depname) values(14,'tamil')

select emp.studentID,emp.name,emp.gender,emp.depid
from [dbo].[employ] emp
inner join [dbo].[depart1] dep
on emp.depid=dep.depid

select emp.studentID,emp.name,emp.gender,emp.depid,dep.depid
from [dbo].[employ] emp
left join [dbo].[depart1] dep
on emp.depid=dep.depid

select emp.studentID,emp.name,emp.gender,emp.depid
from [dbo].[employ] emp
right join [dbo].[depart1] dep
on emp.depid=dep.depid

select * from employ
inner join depart1
on employ.depid=depart1.depid


select * from employ
left join depart1
on employ.depid=depart1.depid

select * from employ
right join depart1
on employ.depid=depart1.depid

select * from employ
full join depart1
on employ.depid=depart1.depid

update employ set depid = 18 where name = 'raja'