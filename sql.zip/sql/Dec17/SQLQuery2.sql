use dec16

select * from [dbo].[person]


alter procedure GetAllPersonDetails
as
begin

select * from [dbo].[person]

select * from [dbo].[order1]

end

--drop procedure GetAllPersonDetails


exec GetAllPersonDetails



create procedure GetSpecificPersonDetails
@id int
as 
begin

 select * from [dbo].[person] where id=@id

end


exec GetSpecificPersonDetails 2


create procedure DeleteSpecificOrderDetails
@id int
as 
begin

 delete from  [dbo].[order1] where id=@id

end


exec DeleteSpecificOrderDetails 4