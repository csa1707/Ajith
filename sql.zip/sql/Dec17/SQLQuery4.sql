select * from [dbo].[person] 


delete from [dbo].[person] where id=1


select * from [dbo].[order1]


delete from [dbo].[order1] where id=1