select * from [dbo].[student]


create procedure getstudentdetails
as
begin
select * from [dbo].[student]
end

exec getstudentdetails

alter procedure getstudentdetails
as
begin
select * from [dbo].[student]
select * from [dbo].[marks]
end

exec getstudentdetails

create procedure getstudentspecificdetails
@studentID int
as
begin
select * from [dbo].[student] where studentID=@studentID
end

exec getstudentspecificdetails 100

create procedure getstudentcountbygender
--alter procedure getstudentcountbygender
@gender varchar(20),
@studentcount int output
as
begin
	select @studentcount = count(studentID) from student where gender = @gender
end

declare @studentcount int
exec getstudentcountbygender 'male', @studentcount output
print @studentcount
t