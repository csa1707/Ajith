use dec16

select * from [dbo].[person]

select * from [dbo].[order1]

alter procedure getpersondetailwihtage25
@age int ,
@name varchar(10) output 
as 
begin

select @name=[name] from  [dbo].[person] where age>@age

end

================



declare @name varchar(10)

exec getpersondetailwihtage25 @age=28,  @name = @name output

print @name


--select @@version


============

/****exception handling****/

--try catch mechanisn

begin try
 declare @num int

 set @num = 15/0

 print 'this will not execute'

end try
begin catch

 print 'this is execption'

end catch

=========================


begin try
 
 insert into [dbo].[person](id,name,age) values('asdasd','raju',31)
 

end try
begin catch

 print('above try block is error  so thrown error here')

end catch
