use [dec16]

select * from [dbo].[person]  where age>20

--index 

--create index idx_person_age 
--on [dbo].[person](age)    ----single column index

--process of data  retrival quickly , fast searchihng mechanism , allows multiple column

select * from [dbo].[person]  where age>20 and name='kumar'

--create index idx_person_age_name
--on [dbo].[person](age,[name])  --composite index



--table variable

DECLARE @ajithtablevariable TABLE
(
name varchar(10),
age int
)

insert into @ajithtablevariable(name,age)  select name ,age from  [dbo].[person]

select * from @ajithtablevariable


create procedure ajithtblbvar
as
begin

DECLARE @ajithtablevariable TABLE
(
name varchar(10),
age int
)

insert into @ajithtablevariable(name,age)  select name ,age from  [dbo].[person]

select * from @ajithtablevariable

end


exec ajithtblbvar


/******************/


create table #ajithtemptable(
name varchar(10),
age int
)

insert into #ajithtemptable(name,age)  select name ,age from  [dbo].[person]

select * from #ajithtemptable

