--create database dotnet

--use dotnet

--create table City
--(
--id int identity(1,1),
--name varchar(10)
--)

--insert into City([name]) values('Chennai');

--insert into City([name]) values('Bangalore');

--insert into City([name]) values('Hyderabad');

--insert into City([name]) values('Mumbai');


select * from City