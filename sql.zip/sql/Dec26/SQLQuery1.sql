use [practice]

select top 1 vegname from vendors order by cost desc

select top 1 vegname,cost,eid from vendors order by cost desc

select * from [dbo].[vendors]


/*****create sp*******/
create procedure getVendors
as
begin 

select eid,vegname ,cost from vendors

end

exec getVendors


/******insert sp*************/
create procedure insertVendor
(
@eid int ,
@vegname varchar(10),
@cost int
)
as
begin

insert into vendors(eid,vegname,cost) values(@eid,@vegname,@cost)

end

--exec insertVendor  108,'brinjal',35 


/**delete sp**/
create procedure removevendor
(
@eid int
)
as
begin

delete from vendors where eid=@eid

end