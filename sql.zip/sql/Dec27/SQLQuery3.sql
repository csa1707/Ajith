--create database webapps

--use webapps


--Create table tblStudent(        --    StudId int IDENTITY(1,1) NOT NULL,        --    Name varchar(20) NOT NULL,        --    City varchar(20) NOT NULL,        --    Department varchar(20) NOT NULL,        --    Gender varchar(6) NOT NULL        --)

select * from tblStudent

--insert into tblStudent(Name,City,Department,Gender) values('Ajith','Chennai','CSE','Male')

--insert into tblStudent(Name,City,Department,Gender) values('Kumar','Bangalore','IT','Male')

--insert into tblStudent(Name,City,Department,Gender) values('Arun','Hyderabad','ECE','Male')

--Create procedure spAddstudent         --(        --    @Name VARCHAR(20),         --    @City VARCHAR(20),        --    @Department VARCHAR(20),        --    @Gender VARCHAR(6)        --)        --as         --Begin         --    Insert into tblstudent (Name,City,Department, Gender)         --    Values (@Name,@City,@Department, @Gender)         --End


--Create procedure spGetAllStudent      --as      --Begin      --    select *      --    from tblStudent   --    order by StudId --End

--Create procedure spUpdateStudent          --(          --   @StudId INTEGER ,        --   @Name VARCHAR(20),         --   @City VARCHAR(20),        --   @Department VARCHAR(20),        --   @Gender VARCHAR(6)        --)          --as          --begin          --   Update tblStudent           --   set Name=@Name,          --   City=@City,          --   Department=@Department,        --   Gender=@Gender          --   where StudId=@StudId          --End


--Create procedure spDeleteStudent         --(          --   @StudId int          --)          --as           --begin          --   Delete from tblStudent where StudId=@StudId          --End


