--use [webapps]

select * from tblStudent

select StudId,name,city,department,gender from tblStudent where StudId=2


sp_helptext [spAddstudent]

