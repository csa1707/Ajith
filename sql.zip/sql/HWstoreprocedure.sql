use practice

create procedure insertvalue
(@eid int,@vegname varchar(20),@cost int)
as 
begin
insert into vendors(eid,vegname,cost) values(@eid,@vegname,@cost)
end
 
exec insertvalue 104
,'mushroom'
,35
 sp_help vendors
 
 --drop proc insertvalue
 select * from vendors
 select * from buyers
create procedure insertvalueupdate
as 
begin
update vendors set vegname='betroot' where eid=103
end

 --drop proc insertvalueupdate

exec insertvalueupdate 

create procedure insertvaluedelete
as 
begin
delete vendors where eid=104
end

exec insertvaluedelete

alter PROCEDURE innerjoinproc
AS
BEGIN  
  SELECT 
     eid,vegname,cost
  FROM vendors
  INNER JOIN buyers ON eid =  personid
END

exec innerjoinproc

create procedure leftjoinproc
as
begin
select eid,vegname,cost,fruitname from vendors left join buyers on eid = personid
end

exec leftjoinproc

create procedure rightjoinproc
as
begin
select eid,vegname,cost,fruitname from vendors right join buyers on eid = personid
end

exec rightjoinproc