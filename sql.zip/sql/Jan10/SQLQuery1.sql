use [webapi1]

select * from notes1

create table notes1(
id bigint identity(1,1),
[description] varchar(max) 
)

sp_help notes

create proc AddNotessp
(
@description varchar(max)
)
as
begin
insert into notes1 (description)
values(@description)
end

drop proc AddNotessp

create proc AddNotessp2
as
begin
insert into notes1 values
end

create proc GetNotessp
as
begin
select * from notes1 order by id
end


create proc DeleteNotessp(@id int)
as
begin
delete from notes1 where id=@id
end


--create proc spupdateveg
--(
--@eid int,
--@vegname varchar(20),
--@cost int
--)
--as
--begin
--update vendors set vegname=@vegname,cost=@cost where eid=@eid
--end


create proc AddNotessp3
(
@id int,
@description varchar(20)
)
as
begin
insert into notes1 (id,description)
values(@id,@description)
end

exec AddNotessp