use practice

select * from [dbo].[vendors]

create proc spaddveg
(
@eid int,
@vegname varchar(20),
@cost int
)
as
begin
insert into vendors (eid,vegname,cost)
values(@eid,@vegname,@cost)
end


create proc spgetallveg
as
begin
select * from vendors order by eid
end


create proc spupdateveg
(
@eid int,
@vegname varchar(20),
@cost int
)
as
begin
update vendors set vegname=@vegname,cost=@cost where eid=@eid
end

create proc spdeleteveg(@eid int)
as
begin
delete from vendors where eid=@eid
end
drop procedure spdeleteveg
create proc spdeletevegetable(@eid int)
as
begin
delete from vendors where eid=@eid
end