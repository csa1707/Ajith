create database practice1

use practice1

create table cars(
carid int IDENTITY(1,1) PRIMARY KEY,
carname varchar(20) NOT NULL,
cost int NOT NULL
)