
select * from employ
create procedure getemploydetails
as
begin 

select studentID,name,gender,depid from employ

end

exec getemploydetails

USE practice
sp_help insertemploydetails

create procedure insertemploydetails
(
@studentID int ,
@name varchar(20),
@gender varchar(20),
@depid int
)
as 
begin

insert into employ
(studentID,name ,gender,depid ) 
values(@studentID,@name,@gender,@depid)

end

exec insertemploydetails 16,rithu,female,12

create proc deletespdata
(
@studentID int
)
as
begin

delete from employ where studentID=@studentID

end

exec deletespdata 17


create proc updatespdata(@depid int,@studentId int)
as
begin

update employ set depid=@depid where studentID=@studentID

end

exec updatespdata 13,16